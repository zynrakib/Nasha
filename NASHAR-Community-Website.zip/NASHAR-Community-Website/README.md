# NASHAR Community Team Website

## Run locally
Open `index.html` in a modern browser.

## Customize before publishing
1. Open `index.html` in a code editor.
2. Find `const ADMIN_PASSWORD = "nashar123";` and change the demo password.
3. Find `const DISCORD_INVITE = "https://discord.gg/your-invite";` and replace it with your real Discord invite URL.
4. In the `starterMembers` list, replace sample names and usernames with your team members. You can also add/edit members from Admin Panel after opening the page.

## Publish with GitHub Pages
1. Create a GitHub repository, for example `nashar-community`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and open the URL shown there.

## Important limitations
This starter uses browser `localStorage`. Added/edited members are saved only in the browser and device where the changes were made. They are not automatically shared with visitors or other admins. The password is also visible in the site's JavaScript, so it is only a demo gate, not secure authentication. Anyone can inspect the source code.

For a real shared admin panel, connect a backend such as Supabase or Firebase:
- authenticated admin accounts
- database-backed team records shared with every visitor
- database security rules / row-level permissions
- never put service-role or private API keys in frontend code

The Export JSON and Import JSON buttons let you back up or move the browser's team list manually.
